<?php
// Copyright 1999-2016. Parallels IP Holdings GmbH.

$application = new pm_Application();
$application->run();
